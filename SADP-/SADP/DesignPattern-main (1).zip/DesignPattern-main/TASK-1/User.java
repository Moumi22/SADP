public class User {
    
    public void login(String userName, String password){

        System.out.println("User Name : " + userName + "\n Password : " + password);
    }
}
