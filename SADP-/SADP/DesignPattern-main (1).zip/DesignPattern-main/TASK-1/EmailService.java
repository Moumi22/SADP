public class EmailService{

    public void sendEmail(String to , String subject , String body){

        System.out.println("To : " + to + "Subject : " + subject + "Body : " + body);
    }
}

