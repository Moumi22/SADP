public class VariableAndDataType {

    public static void main(String[] args) {
        
        int abc = 10;     //int data type
        int xyz = 20;

        String name = "Prottoy";      //String data type

        boolean areYouDeveloper = true;    //boolean data type

        System.out.println(abc + xyz);
        System.out.println(name);
        System.out.println(areYouDeveloper);
        System.out.println("Prottoy is developer? Ans : " + areYouDeveloper);     //variable declaration with concatenation

    }
}

