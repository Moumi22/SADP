
public class PhoneTest {
    
    public static void main(String[] args) {

        Phone myphone = new Phone();   

        myphone.call();
        myphone.text();
        myphone.call(9387889);
        myphone.showModel();
    }

}
