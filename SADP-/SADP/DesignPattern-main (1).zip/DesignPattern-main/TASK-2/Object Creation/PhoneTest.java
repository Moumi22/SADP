
public class PhoneTest {

    public static void main(String[] args) {

        Phone myphone = new Phone();       //Object Creation

        myphone.call();
        myphone.text();
        myphone.showModel();
    }
    
}
