
public class Doctor extends Human {         //Inheritance

    public void howToLoseFat() {

        System.out.println("Well make sure you exercise.");
    }
    

}
