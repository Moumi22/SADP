
public class Teacher extends Human {          //Inheritance
    
    public void givesUsALesson() {

        System.out.println("Dream is not the thing you see in sleep but is that thing that doesn't let you sleep");
    }
}

