
public class Human {

    public void eat() {

        System.out.println("I am eating");
    }

    public void sleep() {

        System.out.println("I am sleeping");
    }

    public void swim() {

        System.out.println("I am swiming");
    }
    

}
