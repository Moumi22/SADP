
public class Singer extends Human {           //Inheritance

    public void singASong() {

        System.out.println("Ek din aap you hamko mil jayenge");
    }


}

